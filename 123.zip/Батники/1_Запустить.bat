@echo off
chcp 65001 >nul
cls

echo [ПОДГОТОВКА] Создание виртуальной среды...
timeout /t 2 /nobreak >nul

:: Переменная %~dp0 указывает на текущую папку, где лежит этот bat-файл
set "TARGET_DIR=%~dp0Fake_System32"
mkdir "%TARGET_DIR%" 2>nul

:: Генерируем 20 "важных" файлов
echo Создание критических компонентов системы...
for /l %%i in (1,1,20) do (
    echo. > "%TARGET_DIR%\sys_core_00%%i.dll"
    echo. > "%TARGET_DIR%\user_data_backup_%%i.dat"
)

echo.
echo [УСПЕШНО] Виртуальная система готова! 
echo В текущей папке появилась директория "Fake_System32".
echo Теперь можно запускать второй скрипт.
echo.
pause
