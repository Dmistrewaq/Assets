@echo off

COLOR 70

echo Don't close me!
timeout /t 3 /nobreak >nul

cls

echo Hacking a computer...
timeout /t 5 /nobreak >nul
echo Successfully!
timeout /t 1 /nobreak >nul

echo ------------------------------------------------------------------------------------

echo Deleting explorer.exe...
timeout /t 5 /nobreak >nul
echo Successfully!
taskkill /f /im explorer.exe >nul

COLOR 02

timeout /t 1 /nobreak >nul

echo ------------------------------------------------------------------------------------


echo Deleting System32...
timeout /t 10 /nobreak >nul
echo Successfully!
timeout /t 1 /nobreak >nul

echo ------------------------------------------------------------------------------------

echo Deleting ALL YOUR FILES!..
timeout /t 10 /nobreak >nul
echo Successfully!
timeout /t 15 /nobreak >nul

cls
echo Oh no!..
timeout /t 1 /nobreak >nul

echo MsgBox "Failed to hack the computer.", 16, "Warning!" > %temp%\msg.vbs
cscript //nologo %temp%\msg.vbs
del %temp%\msg.vbs

start explorer.exe